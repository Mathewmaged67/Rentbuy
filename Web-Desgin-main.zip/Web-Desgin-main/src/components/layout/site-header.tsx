import { Link, useNavigate, useLocation } from "@tanstack/react-router";
import { Search, Heart, ShoppingBag, Sun, Moon, Globe, User, Menu } from "lucide-react";
import * as React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useApp } from "@/store/app-store";
import { CATEGORIES } from "@/data/products";
import { cn } from "@/lib/utils";

export function SiteHeader() {
  const { state, dispatch } = useApp();
  const navigate = useNavigate();
  const location = useLocation();
  const [q, setQ] = React.useState("");

  const submitSearch = (e: React.FormEvent) => {
    e.preventDefault();
    navigate({ to: "/browse", search: { q } as never });
  };

  const cartCount = state.cart.length;
  const wishCount = state.wishlist.length;

  const dashboardHref =
    state.role === "admin"
      ? "/dashboard/admin"
      : state.role === "seller"
      ? "/dashboard/seller"
      : "/dashboard";

  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-3 md:px-6">
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="md:hidden">
              <Menu className="size-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-72">
            <nav className="mt-8 flex flex-col gap-1">
              <Link to="/" className="rounded-md px-3 py-2 hover:bg-muted">Home</Link>
              <Link to="/browse" className="rounded-md px-3 py-2 hover:bg-muted">Browse</Link>
              <Link to="/blogs" className="rounded-md px-3 py-2 hover:bg-muted">Journal</Link>
              <div className="mt-3 px-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Categories</div>
              {CATEGORIES.map((c) => (
                <Link
                  key={c.slug}
                  to="/browse"
                  search={{ category: c.slug } as never}
                  className="rounded-md px-3 py-2 hover:bg-muted"
                >
                  {c.name}
                </Link>
              ))}
            </nav>
          </SheetContent>
        </Sheet>

        <Link to="/" className="flex items-center gap-2">
          <span className="grid size-9 place-items-center rounded-xl bg-gradient-ink text-cream">
            <span className="font-display text-lg font-bold">R</span>
          </span>
          <span className="font-display text-lg font-semibold tracking-tight">
            Rent<span className="text-rent">Buy</span>
          </span>
        </Link>

        <nav className="ml-4 hidden items-center gap-1 md:flex">
          <Link
            to="/browse"
            className={cn(
              "rounded-full px-3 py-1.5 text-sm font-medium transition-colors hover:bg-muted",
              location.pathname.startsWith("/browse") && "bg-muted",
            )}
          >
            Browse
          </Link>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="rounded-full px-3 py-1.5 text-sm font-medium transition-colors hover:bg-muted">
                Categories
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-56">
              {CATEGORIES.map((c) => (
                <DropdownMenuItem
                  key={c.slug}
                  onClick={() => navigate({ to: "/browse", search: { category: c.slug } as never })}
                >
                  {c.name}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
          <Link
            to="/blogs"
            className="rounded-full px-3 py-1.5 text-sm font-medium transition-colors hover:bg-muted"
          >
            Journal
          </Link>
        </nav>

        <form onSubmit={submitSearch} className="ml-auto hidden flex-1 max-w-md md:block">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search gadgets, brands, categories"
              className="h-10 rounded-full pl-9"
            />
          </div>
        </form>

        <div className="ml-auto flex items-center gap-1 md:ml-0">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => dispatch({ type: "TOGGLE_THEME" })}
            aria-label="Toggle theme"
          >
            {state.theme === "dark" ? <Sun className="size-5" /> : <Moon className="size-5" />}
          </Button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" aria-label="Language">
                <Globe className="size-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => dispatch({ type: "SET_LANG", lang: "en" })}>
                English
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => dispatch({ type: "SET_LANG", lang: "ar" })}>
                العربية
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <Link to="/dashboard" search={{ tab: "wishlist" } as never}>
            <Button variant="ghost" size="icon" className="relative" aria-label="Wishlist">
              <Heart className="size-5" />
              {wishCount > 0 && (
                <span className="absolute -right-0.5 -top-0.5 grid size-4 place-items-center rounded-full bg-rent text-[10px] font-bold text-rent-foreground">
                  {wishCount}
                </span>
              )}
            </Button>
          </Link>

          <Link to="/cart">
            <Button variant="ghost" size="icon" className="relative" aria-label="Cart">
              <ShoppingBag className="size-5" />
              {cartCount > 0 && (
                <span className="absolute -right-0.5 -top-0.5 grid size-4 place-items-center rounded-full bg-buy text-[10px] font-bold text-buy-foreground">
                  {cartCount}
                </span>
              )}
            </Button>
          </Link>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" aria-label="Account">
                <User className="size-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              {state.role === "guest" ? (
                <>
                  <DropdownMenuItem onClick={() => navigate({ to: "/auth" })}>
                    Sign in
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => navigate({ to: "/auth", search: { mode: "register" } as never })}>
                    Create account
                  </DropdownMenuItem>
                </>
              ) : (
                <>
                  <DropdownMenuLabel className="text-xs font-normal text-muted-foreground">
                    Signed in as <span className="font-semibold text-foreground">{state.user?.name}</span>
                    <div className="mt-0.5 capitalize">{state.role}</div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => navigate({ to: dashboardHref })}>
                    Dashboard
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuLabel className="text-xs uppercase text-muted-foreground">Switch role (demo)</DropdownMenuLabel>
                  <DropdownMenuItem onClick={() => dispatch({ type: "SET_ROLE", role: "customer", user: state.user ?? { name: "Demo Customer", email: "demo@rentbuy.app" } })}>
                    Customer
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => dispatch({ type: "SET_ROLE", role: "seller", user: state.user ?? { name: "Demo Seller", email: "seller@rentbuy.app" } })}>
                    Seller
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => dispatch({ type: "SET_ROLE", role: "admin", user: state.user ?? { name: "Demo Admin", email: "admin@rentbuy.app" } })}>
                    Admin
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => dispatch({ type: "LOGOUT" })}>
                    Sign out
                  </DropdownMenuItem>
                </>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}
