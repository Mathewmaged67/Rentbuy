import { createFileRoute, useSearch } from "@tanstack/react-router";
import * as React from "react";
import { BarChart3, Users, Boxes, Trash2, ShieldCheck, Ban } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { DashboardSidebar, type DashItem } from "@/components/dashboard-sidebar";
import { useApp } from "@/store/app-store";
import { ConfirmDialog } from "@/components/confirm-dialog";
import { toast } from "sonner";

interface S { tab?: "stats" | "users" | "products" }

export const Route = createFileRoute("/dashboard/admin")({
  validateSearch: (s: Record<string, unknown>): S => ({
    tab: s.tab === "users" || s.tab === "products" ? s.tab : "stats",
  }),
  head: () => ({ meta: [{ title: "Admin dashboard — RentBuy" }] }),
  component: AdminDashboard,
});

const items: DashItem[] = [
  { to: "/dashboard/admin", search: { tab: "stats" }, label: "Stats", icon: BarChart3 },
  { to: "/dashboard/admin", search: { tab: "users" }, label: "Users", icon: Users },
  { to: "/dashboard/admin", search: { tab: "products" }, label: "Products", icon: Boxes },
];

const FAKE_USERS = [
  { id: "u1", name: "Sara Khan", email: "sara@example.com", role: "customer", active: true },
  { id: "u2", name: "Aurora Audio Co.", email: "team@aurora.com", role: "seller", active: true },
  { id: "u3", name: "Lumen Imaging", email: "hello@lumen.io", role: "seller", active: true },
  { id: "u4", name: "Mike Chen", email: "mike@example.com", role: "customer", active: false },
];

function AdminDashboard() {
  const { tab } = useSearch({ from: "/dashboard/admin" });
  const { state, dispatch } = useApp();
  const [users, setUsers] = React.useState(FAKE_USERS);
  const [confirmId, setConfirmId] = React.useState<string | null>(null);

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 md:px-6">
      <h1 className="font-display text-3xl font-semibold md:text-4xl">Admin</h1>
      <p className="mt-1 text-sm text-muted-foreground">Platform health and moderation.</p>

      <div className="mt-8 flex flex-col gap-8 md:flex-row">
        <DashboardSidebar items={items} title="Admin" />
        <div className="flex-1">
          {tab === "stats" && <Stats />}
          {tab === "users" && <UsersTab />}
          {tab === "products" && <ProductsTab />}
        </div>
      </div>

      <ConfirmDialog
        open={!!confirmId}
        onOpenChange={(o) => !o && setConfirmId(null)}
        title="Remove this product?"
        description="This will hide it from the marketplace immediately."
        confirmLabel="Remove product"
        onConfirm={() => {
          if (confirmId) {
            dispatch({ type: "REMOVE_PRODUCT", id: confirmId });
            toast.success("Product removed");
          }
          setConfirmId(null);
        }}
      />
    </div>
  );

  function Stats() {
    const stats = [
      { label: "Products", value: state.products.length },
      { label: "Orders", value: state.orders.length },
      { label: "Messages", value: state.messages.length },
      { label: "Wishlisted", value: state.wishlist.length },
    ];
    return (
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label} className="rounded-2xl border border-border bg-card p-5">
            <div className="text-xs uppercase tracking-wide text-muted-foreground">{s.label}</div>
            <div className="mt-2 font-display text-3xl font-bold">{s.value}</div>
          </div>
        ))}
      </div>
    );
  }

  function UsersTab() {
    return (
      <div className="overflow-hidden rounded-2xl border border-border bg-card">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-left text-xs uppercase tracking-wide text-muted-foreground">
            <tr><th className="px-4 py-3">Name</th><th className="px-4 py-3">Email</th><th className="px-4 py-3">Role</th><th className="px-4 py-3">Status</th><th className="px-4 py-3 text-right">Actions</th></tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id} className="border-t border-border">
                <td className="px-4 py-3 font-medium">{u.name}</td>
                <td className="px-4 py-3 text-muted-foreground">{u.email}</td>
                <td className="px-4 py-3 capitalize">{u.role}</td>
                <td className="px-4 py-3">{u.active ? <Badge className="bg-buy text-buy-foreground hover:bg-buy">Active</Badge> : <Badge variant="secondary">Suspended</Badge>}</td>
                <td className="px-4 py-3">
                  <div className="flex justify-end gap-2">
                    <Button size="sm" variant="outline" onClick={() => setUsers((p) => p.map((x) => x.id === u.id ? { ...x, active: !x.active } : x))}>
                      {u.active ? <><Ban className="size-4" /> Suspend</> : <><ShieldCheck className="size-4" /> Activate</>}
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => setUsers((p) => p.filter((x) => x.id !== u.id))}>
                      <Trash2 className="size-4" />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }

  function ProductsTab() {
    return (
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-3">
        {state.products.map((p) => (
          <div key={p.id} className="rounded-2xl border border-border bg-card p-4">
            <div className="flex gap-3">
              <img src={p.image} alt="" className="size-16 rounded-xl object-cover" />
              <div className="flex-1">
                <div className="font-medium">{p.name}</div>
                <div className="text-xs text-muted-foreground">By {p.sellerName}</div>
              </div>
            </div>
            <Button size="sm" variant="outline" className="mt-3 w-full text-destructive hover:bg-destructive/10" onClick={() => setConfirmId(p.id)}>
              <Trash2 className="size-4" /> Remove
            </Button>
          </div>
        ))}
      </div>
    );
  }
}
