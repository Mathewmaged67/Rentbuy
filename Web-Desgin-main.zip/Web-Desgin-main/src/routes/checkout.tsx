import { createFileRoute, useSearch, useNavigate, Link } from "@tanstack/react-router";
import * as React from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useApp, type Order } from "@/store/app-store";
import { findProduct } from "@/data/products";
import { ShieldCheck } from "lucide-react";

interface S { itemId?: string }

export const Route = createFileRoute("/checkout")({
  validateSearch: (s: Record<string, unknown>): S => ({ itemId: typeof s.itemId === "string" ? s.itemId : undefined }),
  head: () => ({ meta: [{ title: "Checkout — RentBuy" }, { name: "description", content: "Complete your order." }] }),
  component: CheckoutPage,
});

function CheckoutPage() {
  const { itemId } = useSearch({ from: "/checkout" });
  const { state, dispatch } = useApp();
  const navigate = useNavigate();
  const [payment, setPayment] = React.useState<"cod" | "online">("online");

  const ci = state.cart.find((i) => i.id === itemId);
  const product = ci ? findProduct(ci.productId) : null;

  if (!ci || !product) {
    return (
      <div className="mx-auto max-w-md px-6 py-24 text-center">
        <h1 className="font-display text-2xl">Nothing to check out</h1>
        <p className="mt-2 text-sm text-muted-foreground">Your selection is empty or has been removed.</p>
        <Button asChild className="mt-4"><Link to="/cart">Back to cart</Link></Button>
      </div>
    );
  }

  const total = ci.type === "buy" ? product.price : product.rentPerDay * (ci.days ?? 1) + product.deposit;

  function placeOrder(e: React.FormEvent) {
    e.preventDefault();
    if (!ci || !product) return;
    const order: Order = {
      id: "ORD-" + Math.random().toString(36).slice(2, 8).toUpperCase(),
      productId: product.id,
      type: ci.type,
      days: ci.days,
      total,
      payment,
      status: "pending",
      createdAt: new Date().toISOString(),
    };
    dispatch({ type: "PLACE_ORDER", order });
    dispatch({ type: "REMOVE_CART", id: ci.id });
    navigate({ to: "/order-confirmation", state: { order, productName: product.name } as never });
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 md:px-6">
      <h1 className="font-display text-3xl font-semibold md:text-4xl">Checkout</h1>
      <form onSubmit={placeOrder} className="mt-8 grid grid-cols-1 gap-8 lg:grid-cols-[1fr_360px]">
        <div className="space-y-6">
          <section className="rounded-2xl border border-border bg-card p-5">
            <h2 className="font-display text-lg font-semibold">Shipping address</h2>
            <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="space-y-1.5"><Label>Full name</Label><Input defaultValue={state.user?.name} required /></div>
              <div className="space-y-1.5"><Label>Email</Label><Input type="email" defaultValue={state.user?.email} required /></div>
              <div className="space-y-1.5 sm:col-span-2"><Label>Address</Label><Input placeholder="Street, building, apt." required /></div>
              <div className="space-y-1.5"><Label>City</Label><Input required /></div>
              <div className="space-y-1.5"><Label>Postal code</Label><Input required /></div>
            </div>
          </section>

          <section className="rounded-2xl border border-border bg-card p-5">
            <h2 className="font-display text-lg font-semibold">Payment method</h2>
            <RadioGroup value={payment} onValueChange={(v) => setPayment(v as "cod" | "online")} className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
              <Label className="flex cursor-pointer items-center gap-2 rounded-xl border border-border p-3 hover:bg-muted">
                <RadioGroupItem value="online" /> Online (simulated)
              </Label>
              <Label className="flex cursor-pointer items-center gap-2 rounded-xl border border-border p-3 hover:bg-muted">
                <RadioGroupItem value="cod" /> Cash on delivery
              </Label>
            </RadioGroup>
          </section>
        </div>

        <aside className="h-fit space-y-4 rounded-2xl border border-border bg-card p-5">
          <h2 className="font-display text-lg font-semibold">Order summary</h2>
          <div className="flex gap-3">
            <img src={product.image} alt={product.name} className="size-20 rounded-lg object-cover" />
            <div className="flex-1">
              <div className="font-medium">{product.name}</div>
              <div className="text-xs text-muted-foreground">
                {ci.type === "buy" ? "Buy" : `Rent · ${ci.days} days · includes $${product.deposit} deposit`}
              </div>
            </div>
          </div>
          <div className="flex items-center justify-between border-t border-border pt-3">
            <span className="text-sm text-muted-foreground">Total</span>
            <span className="font-display text-2xl font-bold">${total.toFixed(0)}</span>
          </div>
          <Button type="submit" className="w-full bg-gradient-ink" size="lg">Confirm order</Button>
          <p className="flex items-center justify-center gap-1.5 text-xs text-muted-foreground">
            <ShieldCheck className="size-3.5 text-buy" /> Secure checkout · Refundable deposit
          </p>
        </aside>
      </form>
    </div>
  );
}
