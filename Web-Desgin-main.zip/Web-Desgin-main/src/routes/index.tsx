import { createFileRoute, Link } from "@tanstack/react-router";
import * as React from "react";
import { ArrowRight, Sparkles, ShieldCheck, Truck, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { ProductCard } from "@/components/product-card";
import { useApp } from "@/store/app-store";
import { CATEGORIES } from "@/data/products";
import { useReveal } from "@/hooks/use-reveal";
import heroImg from "@/assets/hero-gadgets.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "RentBuy — Buy or rent the best gadgets" },
      { name: "description", content: "Premium electronics marketplace with two ways to own: buy outright or rent by the day." },
      { property: "og:title", content: "RentBuy — Buy or rent the best gadgets" },
      { property: "og:description", content: "Premium electronics marketplace with two ways to own: buy outright or rent by the day." },
    ],
  }),
  component: HomePage,
});

function HomePage() {
  const { state } = useApp();
  useReveal();

  const featured = state.products.filter((p) => p.featured).slice(0, 8);
  const bestSelling = state.products.filter((p) => p.bestSelling).slice(0, 8);
  const newest = state.products.filter((p) => p.isNew).slice(0, 8);

  return (
    <div className="space-y-24">
      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-hero opacity-90" aria-hidden />
        <div className="relative mx-auto grid max-w-7xl grid-cols-1 items-center gap-10 px-4 py-16 md:grid-cols-2 md:gap-14 md:px-6 md:py-24">
          <div>
            <Badge className="bg-foreground/10 text-foreground hover:bg-foreground/10">
              <Sparkles className="size-3.5" /> Two ways to own
            </Badge>
            <h1 className="mt-5 font-display text-5xl font-semibold leading-[1.05] tracking-tight md:text-6xl lg:text-7xl">
              Buy what you love. <br />
              <span className="font-serif-italic text-rent">Rent</span> what you need.
            </h1>
            <p className="mt-5 max-w-lg text-base text-foreground/70 md:text-lg">
              From cinema-grade cameras to studio headphones — get the gear without the long-term commitment. Deposit-protected, delivered fast.
            </p>
            <div className="mt-7 flex flex-wrap items-center gap-3">
              <Button asChild size="lg" className="bg-gradient-ink text-cream shadow-soft">
                <Link to="/browse">Shop the marketplace <ArrowRight className="size-4" /></Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="border-foreground/20">
                <Link to="/browse" search={{ mode: "rent" } as never}>Browse rentals</Link>
              </Button>
            </div>
            <ul className="mt-8 flex flex-wrap gap-x-6 gap-y-2 text-sm text-foreground/70">
              <li className="flex items-center gap-2"><ShieldCheck className="size-4 text-buy" /> Deposit-protected</li>
              <li className="flex items-center gap-2"><Truck className="size-4 text-buy" /> Fast delivery</li>
              <li className="flex items-center gap-2"><RefreshCw className="size-4 text-buy" /> 14-day returns</li>
            </ul>
          </div>
          <div className="relative">
            <div className="absolute -inset-6 rounded-[2rem] bg-gradient-rent opacity-20 blur-3xl" aria-hidden />
            <div className="relative overflow-hidden rounded-[2rem] border border-border/60 shadow-elevated">
              <img
                src={heroImg}
                alt="Premium gadgets — headphones, camera, drone, smartwatch"
                width={1536}
                height={1152}
                className="w-full object-cover"
              />
              <div className="pointer-events-none absolute bottom-4 left-4 flex flex-col gap-2">
                <span className="rounded-full bg-background/85 px-3 py-1 text-xs font-medium backdrop-blur">
                  ★ 4.8 · 12,400+ reviews
                </span>
                <span className="rounded-full bg-background/85 px-3 py-1 text-xs font-medium backdrop-blur">
                  Free shipping over $50
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CATEGORIES */}
      <section className="mx-auto max-w-7xl px-4 md:px-6 reveal-on-scroll">
        <div className="flex items-end justify-between">
          <div>
            <h2 className="font-display text-3xl font-semibold tracking-tight md:text-4xl">Shop by category</h2>
            <p className="mt-2 text-muted-foreground">Curated picks across the gear that matters.</p>
          </div>
          <Link to="/browse" className="hidden text-sm font-medium hover:underline md:inline-flex items-center gap-1">
            View all <ArrowRight className="size-4" />
          </Link>
        </div>
        <div className="mt-8 grid grid-cols-2 gap-3 md:grid-cols-4 lg:grid-cols-7">
          {CATEGORIES.map((c, i) => (
            <Link
              key={c.slug}
              to="/browse"
              search={{ category: c.slug } as never}
              className="group relative overflow-hidden rounded-2xl border border-border bg-card p-5 transition-colors hover:bg-foreground hover:text-background"
            >
              <div className="text-xs text-muted-foreground group-hover:text-background/70">0{i + 1}</div>
              <div className="mt-8 font-display text-base font-semibold">{c.name}</div>
              <ArrowRight className="absolute bottom-4 right-4 size-4 -translate-x-2 opacity-0 transition group-hover:translate-x-0 group-hover:opacity-100" />
            </Link>
          ))}
        </div>
      </section>

      {/* PROMO CARDS */}
      <section className="mx-auto grid max-w-7xl grid-cols-1 gap-5 px-4 md:grid-cols-2 md:px-6 reveal-on-scroll">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-rent p-8 text-rent-foreground md:p-10">
          <div className="max-w-sm">
            <Badge className="bg-foreground/15 text-foreground hover:bg-foreground/15">Rent</Badge>
            <h3 className="mt-3 font-display text-3xl font-semibold leading-tight">
              Try the gear before you commit.
            </h3>
            <p className="mt-2 text-foreground/80">
              Daily rates, refundable deposits, and rapid delivery. Perfect for a shoot, a trip, or a weekend project.
            </p>
            <Button asChild className="mt-5 bg-foreground text-background hover:opacity-90">
              <Link to="/browse" search={{ mode: "rent" } as never}>Browse rentals</Link>
            </Button>
          </div>
        </div>
        <div className="relative overflow-hidden rounded-3xl bg-gradient-buy p-8 text-buy-foreground md:p-10">
          <div className="max-w-sm">
            <Badge className="bg-background/15 text-background hover:bg-background/15">Buy</Badge>
            <h3 className="mt-3 font-display text-3xl font-semibold leading-tight">
              Latest releases, curated.
            </h3>
            <p className="mt-2 text-background/85">
              Only the gear we'd buy ourselves — vetted by experts, backed by a 14-day return.
            </p>
            <Button asChild variant="secondary" className="mt-5">
              <Link to="/browse" search={{ mode: "buy" } as never}>Shop now</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* TRENDING TABS */}
      <section className="mx-auto max-w-7xl px-4 md:px-6 reveal-on-scroll">
        <div className="flex items-end justify-between">
          <h2 className="font-display text-3xl font-semibold tracking-tight md:text-4xl">Trending now</h2>
          <Link to="/browse" className="text-sm font-medium hover:underline">See all</Link>
        </div>
        <Tabs defaultValue="new" className="mt-6">
          <TabsList className="bg-muted">
            <TabsTrigger value="new">New</TabsTrigger>
            <TabsTrigger value="best">Best Selling</TabsTrigger>
            <TabsTrigger value="featured">Featured</TabsTrigger>
          </TabsList>
          <TabsContent value="new" className="mt-6">
            <ProductGrid products={newest.length ? newest : featured} />
          </TabsContent>
          <TabsContent value="best" className="mt-6">
            <ProductGrid products={bestSelling} />
          </TabsContent>
          <TabsContent value="featured" className="mt-6">
            <ProductGrid products={featured} />
          </TabsContent>
        </Tabs>
      </section>
    </div>
  );
}

function ProductGrid({ products }: { products: React.ComponentProps<typeof ProductCard>["product"][] }) {
  return (
    <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
      {products.map((p) => (
        <ProductCard key={p.id} product={p} />
      ))}
    </div>
  );
}
