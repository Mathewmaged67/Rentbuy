import { createFileRoute, useSearch, useNavigate, Link } from "@tanstack/react-router";
import * as React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useApp } from "@/store/app-store";

interface S { mode?: "login" | "register" }

export const Route = createFileRoute("/auth")({
  validateSearch: (s: Record<string, unknown>): S => ({ mode: s.mode === "register" ? "register" : "login" }),
  head: () => ({ meta: [{ title: "Sign in — RentBuy" }] }),
  component: AuthPage,
});

function AuthPage() {
  const { mode } = useSearch({ from: "/auth" });
  const navigate = useNavigate();
  const { dispatch } = useApp();
  const isRegister = mode === "register";

  const [name, setName] = React.useState("");
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [err, setErr] = React.useState<string | null>(null);

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!email.includes("@") || password.length < 6 || (isRegister && name.trim().length < 2)) {
      setErr("Please enter a valid email, password (6+ chars), and name.");
      return;
    }
    const inferredRole = email.includes("admin") ? "admin" : email.includes("seller") ? "seller" : "customer";
    dispatch({
      type: "SET_ROLE",
      role: inferredRole,
      user: { name: name || email.split("@")[0], email },
    });
    const dest = inferredRole === "admin" ? "/dashboard/admin" : inferredRole === "seller" ? "/dashboard/seller" : "/dashboard";
    navigate({ to: dest });
  }

  return (
    <div className="mx-auto grid min-h-[80vh] max-w-md place-items-center px-6 py-10">
      <div className="w-full">
        <div className="mb-6 text-center">
          <h1 className="font-display text-3xl font-semibold">{isRegister ? "Create your account" : "Welcome back"}</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Tip: use an email with <span className="font-mono">seller</span> or <span className="font-mono">admin</span> to demo those roles.
          </p>
        </div>
        <form onSubmit={submit} className="space-y-4 rounded-2xl border border-border bg-card p-6 shadow-soft">
          {isRegister && (
            <div className="space-y-1.5">
              <Label htmlFor="name">Full name</Label>
              <Input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Jane Doe" />
            </div>
          )}
          <div className="space-y-1.5">
            <Label htmlFor="email">Email</Label>
            <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="password">Password</Label>
            <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" />
          </div>
          {err && <p className="text-sm text-destructive">{err}</p>}
          <Button type="submit" className="w-full bg-gradient-ink">{isRegister ? "Create account" : "Sign in"}</Button>
          <div className="text-center text-sm text-muted-foreground">
            {isRegister ? (
              <>Already have an account? <Link to="/auth" className="font-medium text-foreground hover:underline">Sign in</Link></>
            ) : (
              <>New to RentBuy? <Link to="/auth" search={{ mode: "register" } as never} className="font-medium text-foreground hover:underline">Create account</Link></>
            )}
          </div>
        </form>
      </div>
    </div>
  );
}
