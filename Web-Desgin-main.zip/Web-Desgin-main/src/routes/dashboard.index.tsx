import { createFileRoute, useSearch, Link } from "@tanstack/react-router";
import * as React from "react";
import { ShoppingBag, Heart, Inbox, Trash2, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { DashboardSidebar, type DashItem } from "@/components/dashboard-sidebar";
import { StatusBadge } from "@/components/status-badge";
import { useApp } from "@/store/app-store";
import { findProduct } from "@/data/products";
import { ProductCard } from "@/components/product-card";

interface S { tab?: "orders" | "wishlist" | "inbox" }

export const Route = createFileRoute("/dashboard/")({
  validateSearch: (s: Record<string, unknown>): S => ({
    tab: s.tab === "wishlist" || s.tab === "inbox" ? s.tab : "orders",
  }),
  head: () => ({ meta: [{ title: "My dashboard — RentBuy" }] }),
  component: CustomerDashboard,
});

const items: DashItem[] = [
  { to: "/dashboard", search: { tab: "orders" }, label: "My Orders", icon: ShoppingBag },
  { to: "/dashboard", search: { tab: "wishlist" }, label: "Wishlist", icon: Heart },
  { to: "/dashboard", search: { tab: "inbox" }, label: "Inbox", icon: Inbox },
];

function CustomerDashboard() {
  const { tab } = useSearch({ from: "/dashboard/" });
  const { state, dispatch } = useApp();

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 md:px-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-3xl font-semibold md:text-4xl">My account</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {state.user ? `Welcome, ${state.user.name}` : <Link to="/auth" className="underline">Sign in</Link>}
          </p>
        </div>
      </div>

      <div className="mt-8 flex flex-col gap-8 md:flex-row">
        <DashboardSidebar items={items} title="Customer" />

        <div className="flex-1">
          {tab === "orders" && <OrdersTab />}
          {tab === "wishlist" && <WishlistTab />}
          {tab === "inbox" && <InboxTab />}
        </div>
      </div>
    </div>
  );

  function OrdersTab() {
    if (state.orders.length === 0) {
      return <Empty title="No orders yet" body="Once you place an order, it'll show up here." cta={<Button asChild><Link to="/browse">Browse products</Link></Button>} />;
    }
    return (
      <div className="overflow-hidden rounded-2xl border border-border bg-card">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-left text-xs uppercase tracking-wide text-muted-foreground">
            <tr>
              <th className="px-4 py-3">Order</th>
              <th className="px-4 py-3">Item</th>
              <th className="px-4 py-3">Type</th>
              <th className="px-4 py-3">Total</th>
              <th className="px-4 py-3">Status</th>
            </tr>
          </thead>
          <tbody>
            {state.orders.map((o) => {
              const p = findProduct(o.productId);
              return (
                <tr key={o.id} className="border-t border-border">
                  <td className="px-4 py-3 font-mono text-xs">{o.id}</td>
                  <td className="px-4 py-3">{p?.name ?? "—"}</td>
                  <td className="px-4 py-3 capitalize">{o.type}{o.days ? ` · ${o.days}d` : ""}</td>
                  <td className="px-4 py-3 font-display font-semibold">${o.total.toFixed(0)}</td>
                  <td className="px-4 py-3"><StatusBadge status={o.status} /></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    );
  }

  function WishlistTab() {
    const list = state.wishlist.map((id) => findProduct(id)).filter(Boolean) as NonNullable<ReturnType<typeof findProduct>>[];
    if (list.length === 0) return <Empty title="Your wishlist is empty" body="Tap the heart on any product to save it." cta={<Button asChild><Link to="/browse">Find something</Link></Button>} />;
    return (
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {list.map((p) => <ProductCard key={p.id} product={p} />)}
      </div>
    );
  }

  function InboxTab() {
    if (state.messages.length === 0) return <Empty title="Inbox empty" body="Messages between you and sellers appear here." />;
    return (
      <div className="space-y-3">
        {state.messages.map((m) => {
          const p = findProduct(m.productId);
          return (
            <div key={m.id} className="rounded-2xl border border-border bg-card p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2 text-sm">
                    <Mail className="size-4 text-muted-foreground" />
                    <span className="font-medium">{p?.name}</span>
                    {m.unread && <span className="rounded-full bg-rent px-2 py-0.5 text-[10px] font-bold text-rent-foreground">NEW</span>}
                  </div>
                  <div className="mt-1 text-xs text-muted-foreground">From {m.fromName} · {new Date(m.createdAt).toLocaleString()}</div>
                </div>
                <Button size="sm" variant="ghost" onClick={() => dispatch({ type: "MARK_READ", id: m.id })}>Mark read</Button>
              </div>
              <p className="mt-3 text-sm">{m.body}</p>
              {m.reply && (
                <div className="mt-3 rounded-xl bg-muted p-3 text-sm">
                  <div className="mb-1 text-xs font-medium text-muted-foreground">Seller reply</div>
                  {m.reply}
                </div>
              )}
            </div>
          );
        })}
      </div>
    );
  }

  function Empty({ title, body, cta }: { title: string; body: string; cta?: React.ReactNode }) {
    return (
      <div className="rounded-2xl border border-dashed border-border bg-card p-12 text-center">
        <h3 className="font-display text-lg font-semibold">{title}</h3>
        <p className="mt-1 text-sm text-muted-foreground">{body}</p>
        {cta && <div className="mt-4">{cta}</div>}
      </div>
    );
  }
}

// Avoid unused-import warnings
void Trash2;
