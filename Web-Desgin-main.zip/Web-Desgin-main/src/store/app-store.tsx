import * as React from "react";
import { PRODUCTS, type Product } from "@/data/products";

export type Role = "guest" | "customer" | "seller" | "admin";
export type ItemType = "buy" | "rent";

export interface CartItem {
  id: string;
  productId: string;
  type: ItemType;
  days?: number;
  qty: number;
}

export type OrderStatus = "pending" | "approved" | "rejected" | "completed";

export interface Order {
  id: string;
  productId: string;
  type: ItemType;
  days?: number;
  total: number;
  payment: "cod" | "online";
  status: OrderStatus;
  createdAt: string;
}

export interface Message {
  id: string;
  productId: string;
  fromName: string;
  fromEmail: string;
  body: string;
  reply?: string;
  createdAt: string;
  unread: boolean;
}

interface State {
  role: Role;
  user: { name: string; email: string } | null;
  theme: "light" | "dark";
  lang: "en" | "ar";
  wishlist: string[];
  cart: CartItem[];
  orders: Order[];
  messages: Message[];
  products: Product[];
}

type Action =
  | { type: "SET_ROLE"; role: Role; user?: { name: string; email: string } | null }
  | { type: "LOGOUT" }
  | { type: "TOGGLE_THEME" }
  | { type: "SET_LANG"; lang: "en" | "ar" }
  | { type: "TOGGLE_WISHLIST"; productId: string }
  | { type: "ADD_TO_CART"; item: CartItem }
  | { type: "REMOVE_CART"; id: string }
  | { type: "CLEAR_CART" }
  | { type: "PLACE_ORDER"; order: Order }
  | { type: "SET_ORDER_STATUS"; id: string; status: OrderStatus }
  | { type: "ADD_MESSAGE"; message: Message }
  | { type: "REPLY_MESSAGE"; id: string; reply: string }
  | { type: "MARK_READ"; id: string }
  | { type: "ADD_PRODUCT"; product: Product }
  | { type: "TOGGLE_PRODUCT_AVAIL"; id: string }
  | { type: "REMOVE_PRODUCT"; id: string }
  | { type: "HYDRATE"; state: State };

const initialState: State = {
  role: "guest",
  user: null,
  theme: "light",
  lang: "en",
  wishlist: [],
  cart: [],
  orders: [],
  messages: [
    {
      id: "m-seed-1",
      productId: "p-001",
      fromName: "Sara",
      fromEmail: "sara@example.com",
      body: "Hi! Is the headphone available for a 4-day rental next week?",
      createdAt: new Date().toISOString(),
      unread: true,
    },
  ],
  products: PRODUCTS,
};

function reducer(state: State, action: Action): State {
  switch (action.type) {
    case "HYDRATE":
      return action.state;
    case "SET_ROLE":
      return { ...state, role: action.role, user: action.user ?? state.user };
    case "LOGOUT":
      return { ...state, role: "guest", user: null };
    case "TOGGLE_THEME":
      return { ...state, theme: state.theme === "light" ? "dark" : "light" };
    case "SET_LANG":
      return { ...state, lang: action.lang };
    case "TOGGLE_WISHLIST":
      return {
        ...state,
        wishlist: state.wishlist.includes(action.productId)
          ? state.wishlist.filter((id) => id !== action.productId)
          : [...state.wishlist, action.productId],
      };
    case "ADD_TO_CART":
      return { ...state, cart: [...state.cart, action.item] };
    case "REMOVE_CART":
      return { ...state, cart: state.cart.filter((i) => i.id !== action.id) };
    case "CLEAR_CART":
      return { ...state, cart: [] };
    case "PLACE_ORDER":
      return { ...state, orders: [action.order, ...state.orders] };
    case "SET_ORDER_STATUS":
      return {
        ...state,
        orders: state.orders.map((o) =>
          o.id === action.id ? { ...o, status: action.status } : o,
        ),
      };
    case "ADD_MESSAGE":
      return { ...state, messages: [action.message, ...state.messages] };
    case "REPLY_MESSAGE":
      return {
        ...state,
        messages: state.messages.map((m) =>
          m.id === action.id ? { ...m, reply: action.reply } : m,
        ),
      };
    case "MARK_READ":
      return {
        ...state,
        messages: state.messages.map((m) =>
          m.id === action.id ? { ...m, unread: false } : m,
        ),
      };
    case "ADD_PRODUCT":
      return { ...state, products: [action.product, ...state.products] };
    case "TOGGLE_PRODUCT_AVAIL":
      return {
        ...state,
        products: state.products.map((p) =>
          p.id === action.id ? { ...p, available: !p.available } : p,
        ),
      };
    case "REMOVE_PRODUCT":
      return { ...state, products: state.products.filter((p) => p.id !== action.id) };
    default:
      return state;
  }
}

interface Ctx {
  state: State;
  dispatch: React.Dispatch<Action>;
}

const AppCtx = React.createContext<Ctx | null>(null);

const STORAGE_KEY = "rentbuy:v1";

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = React.useReducer(reducer, initialState);
  const hydrated = React.useRef(false);

  React.useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as State;
        // Re-attach product images from PRODUCTS list to avoid stale assets
        parsed.products = parsed.products?.length
          ? parsed.products.map((p) => {
              const fresh = PRODUCTS.find((x) => x.id === p.id);
              return fresh ? { ...p, image: fresh.image, gallery: fresh.gallery } : p;
            })
          : PRODUCTS;
        dispatch({ type: "HYDRATE", state: { ...initialState, ...parsed } });
      }
    } catch {
      /* noop */
    }
    hydrated.current = true;
  }, []);

  React.useEffect(() => {
    if (!hydrated.current) return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      /* noop */
    }
  }, [state]);

  React.useEffect(() => {
    const root = document.documentElement;
    if (state.theme === "dark") root.classList.add("dark");
    else root.classList.remove("dark");
  }, [state.theme]);

  return <AppCtx.Provider value={{ state, dispatch }}>{children}</AppCtx.Provider>;
}

export function useApp() {
  const ctx = React.useContext(AppCtx);
  if (!ctx) throw new Error("useApp must be used inside AppProvider");
  return ctx;
}
